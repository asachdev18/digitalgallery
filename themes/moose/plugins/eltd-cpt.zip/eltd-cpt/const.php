<?php

define('ELATED_CPT_VERSION', '2.1');
define('ELATED_CPT_ABS_PATH', dirname(__FILE__));
define('ELATED_CPT_REL_PATH', dirname(plugin_basename(__FILE__ )));
define('ELATED_CPT_URL_PATH', plugin_dir_url( __FILE__ ) );
define('ELATED_CPT_CPT_PATH', ELATED_CPT_ABS_PATH.'/post-types');
define('ELATED_CPT_MODULES_PATH', ELATED_CPT_ABS_PATH . '/modules' );
define('ELATED_CPT_MODULES_URL_PATH', ELATED_CPT_URL_PATH . 'modules' );