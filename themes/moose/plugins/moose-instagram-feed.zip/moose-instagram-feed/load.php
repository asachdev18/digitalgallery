<?php

include_once 'lib/moose-instagram-api.php';
include_once 'widgets/load.php';