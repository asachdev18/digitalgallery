<?php
/*
Plugin Name: Elated Twitter Feed
Description: Plugin that adds Twitter feed functionality to our theme
Author: Elated Themes
Version: 1.0
*/
define('ELTD_TWITTER_FEED_VERSION', '1.0');

include_once 'load.php';